import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_common/get_reset.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:scoketio/utils/colors.dart';
import 'package:scoketio/widgets/custom_button.dart';
import 'package:scoketio/widgets/texts/poppins.dart';

import '../utils/assets.dart';
import '../widgets/custom_app_bar.dart';

class SignupPage extends StatelessWidget {
  const SignupPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: CustomAppBar(),
      body: Container(
        padding: EdgeInsets.all(20),
        color: AppColors.whiteColor,
        child: Center(
          child: Column(
            children: [
              SvgPicture.asset(
                Assets.svg.wellComeSvg,
                semanticsLabel: "Welcome Image",
              ),
              const Poppins(
                color: AppColors.primaryColor,
                size: 35,
                weight: FontWeight.w600,
                label: "Discover Your \nDream Job here",
                maxLines: 2,
                align: TextAlign.center,
              ),
              SizedBox(height: 10,),
              const Poppins(
                color: AppColors.blackColor,
                size: 14,
                maxLines: 2,
                label: "Explore all the existing job roles based on your\n interest and study major",

                align: TextAlign.center,
              ),
              Container(

                child: Row(
                  children: [
                    Expanded( // Ensures the button fits within the Row
                      child: CustomCircularButton(
                            elevation: 3,
                          corners: 10,
                          isPrimaryColor: true,
                          callbackAction: () {}, btnLabel: "Login"),
                    ),
                    SizedBox(width: 10,),
                    Expanded( // Ensures the button fits within the Row
                      child: CustomCircularButton(
                            corners: 10,
                          callbackAction: () {}, btnLabel: "Login"),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
