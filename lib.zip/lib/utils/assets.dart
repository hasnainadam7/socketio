class Assets {
  Assets._();

  static final images = _AssetsImages._();
  static final svg = _AssetsSvg._();
}

class _AssetsImages {
  _AssetsImages._();

}

class _AssetsSvg {
  _AssetsSvg._();
  final String wellComeSvg = "assets/images/welcome_image.svg";
}